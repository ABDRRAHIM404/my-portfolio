document.getElementById('year').textContent = new Date().getFullYear();
    const menuButton = document.getElementById('menuButton');
    const nav = document.getElementById('mainNav');
    menuButton.addEventListener('click', () => {const isOpen = nav.classList.toggle('open');menuButton.setAttribute('aria-expanded', String(isOpen));menuButton.setAttribute('aria-label',isOpen?'Close navigation':'Open navigation')});
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuButton.setAttribute('aria-expanded','false')}));
    if ('IntersectionObserver' in window){const observer = new IntersectionObserver((entries)=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}})},{threshold:.08});document.querySelectorAll('.reveal').forEach(el=>observer.observe(el))}else{document.querySelectorAll('.reveal').forEach(el=>el.classList.add('visible'))}


// English / French language switcher, kept fully offline.
function setPortfolioLanguage(lang) {
  if (!['en', 'fr'].includes(lang)) return;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const values = portfolioTranslations[el.dataset.i18n];
    if (values && values[lang]) el.innerHTML = values[lang];
  });
  document.documentElement.lang = lang;
  document.title = lang === 'fr' ? 'Abderrahim Bounga — Portfolio développeur' : 'Abderrahim Bounga — Developer Portfolio';
  document.querySelector('meta[name="description"]').content = lang === 'fr' ? 'Portfolio de développeur d’Abderrahim Bounga : projets, compétences, expériences et contact.' : 'Abderrahim Bounga — developer portfolio. Explore selected web and app projects, skills, and ways to connect.';
  document.querySelectorAll('.lang-btn').forEach(button => {
    const selected = button.dataset.lang === lang;
    button.classList.toggle('active', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
  try {localStorage.setItem('portfolio-language', lang);} catch(e) {}
}
document.querySelectorAll('.lang-btn').forEach(button => button.addEventListener('click', () => setPortfolioLanguage(button.dataset.lang)));
let savedLanguage = 'en';
try {savedLanguage = localStorage.getItem('portfolio-language') || 'en';} catch(e) {}
setPortfolioLanguage(savedLanguage);


// Hero magical effects: cursor spotlight + subtle 3D parallax.
(() => {
  const hero = document.getElementById('hero');
  if (!hero) return;
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const copy = hero.querySelector('.hero-copy-inner');
  const art = hero.querySelector('.hero-art-inner');
  const shell = hero.querySelector('.portrait-shell');
  const chips = hero.querySelectorAll('.portrait-chip');
  const orbits = hero.querySelectorAll('.portrait-orbit');

  function resetEffects() {
    hero.style.setProperty('--mx', '50%');
    hero.style.setProperty('--my', '42%');
    hero.style.setProperty('--copyX', '0px');
    hero.style.setProperty('--copyY', '0px');
    hero.style.setProperty('--artX', '0px');
    hero.style.setProperty('--artY', '0px');
    hero.style.setProperty('--tiltX', '0deg');
    hero.style.setProperty('--tiltY', '0deg');
    hero.style.setProperty('--chipX', '0px');
    hero.style.setProperty('--chipY', '0px');
    hero.style.setProperty('--orbitX', '0px');
    hero.style.setProperty('--orbitY', '0px');
  }

  function updateFromPointer(clientX, clientY) {
    const rect = hero.getBoundingClientRect();
    const px = (clientX - rect.left) / rect.width;
    const py = (clientY - rect.top) / rect.height;
    const cx = px - 0.5;
    const cy = py - 0.5;
    hero.style.setProperty('--mx', `${(px * 100).toFixed(2)}%`);
    hero.style.setProperty('--my', `${(py * 100).toFixed(2)}%`);
    hero.style.setProperty('--copyX', `${(-cx * 10).toFixed(2)}px`);
    hero.style.setProperty('--copyY', `${(-cy * 8).toFixed(2)}px`);
    hero.style.setProperty('--artX', `${(cx * 14).toFixed(2)}px`);
    hero.style.setProperty('--artY', `${(cy * 12).toFixed(2)}px`);
    hero.style.setProperty('--tiltX', `${(-cy * 7).toFixed(2)}deg`);
    hero.style.setProperty('--tiltY', `${(cx * 8).toFixed(2)}deg`);
    hero.style.setProperty('--chipX', `${(cx * 18).toFixed(2)}px`);
    hero.style.setProperty('--chipY', `${(cy * 14).toFixed(2)}px`);
    hero.style.setProperty('--orbitX', `${(cx * 20).toFixed(2)}px`);
    hero.style.setProperty('--orbitY', `${(cy * 20).toFixed(2)}px`);
  }

  if (!reduce.matches && finePointer.matches) {
    hero.addEventListener('mousemove', (e) => updateFromPointer(e.clientX, e.clientY));
    hero.addEventListener('mouseleave', resetEffects);
  } else {
    resetEffects();
  }

  const syncModes = () => {
    if (reduce.matches || !finePointer.matches) resetEffects();
  };
  reduce.addEventListener?.('change', syncModes);
  finePointer.addEventListener?.('change', syncModes);
  resetEffects();
})();
