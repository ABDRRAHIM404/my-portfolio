// Smooth, scroll-controlled curtain with no document movement during the intro.
(() => {
  const curtain = document.getElementById('openingCurtain');
  if (!curtain) return;
  const left = curtain.querySelector('.wing-left');
  const right = curtain.querySelector('.wing-right');
  const center = curtain.querySelector('.curtain-center');
  const bar = curtain.querySelector('.curtain-progress-bar');
  const suffixes = [...curtain.querySelectorAll('.curtain-suffix')];
  const suffixWidths = suffixes.map(el => { el.style.width = 'auto'; const width = el.getBoundingClientRect().width; el.style.width = '0px'; return width; });
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  const root = document.documentElement;
  let target = 0;
  let displayed = 0;
  let ticking = false;
  let opened = false;
  let touchY = null;
  const travel = () => Math.max(440, window.innerHeight * 0.85);
  const clamp = n => Math.min(1, Math.max(0, n));

  function paint(progress) {
    // Ease the panels: no movement or scaling of the actual website.
    const eased = progress * progress * (3 - 2 * progress);
    left.style.transform = `translate3d(${-105 * eased}%,0,0)`;
    right.style.transform = `translate3d(${105 * eased}%,0,0)`;
    // Unfold each initial into its full name during the first half of the opening.
    const nameProgress = clamp((progress - 0.035) / 0.47);
    const nameEase = 1 - Math.pow(1 - nameProgress, 3);
    suffixes.forEach((el, i) => {
      el.style.width = `${suffixWidths[i] * nameEase}px`;
      el.style.opacity = String(clamp(nameProgress * 5));
    });
    // The complete name fades as the panels move aside.
    center.style.opacity = String(clamp(1 - Math.max(0, progress - 0.53) / 0.32));
    curtain.style.setProperty('--name-opacity', String(clamp(1 - progress * 2.0)));
    curtain.style.setProperty('--seam-intensity', String(clamp(0.68 + progress * 1.2 - eased * 2)));
    bar.style.transform = `scaleX(${progress})`;
  }
  function lock() {
    root.classList.add('curtain-locked');
    curtain.style.visibility = 'visible';
    curtain.style.pointerEvents = 'auto';
    opened = false;
  }
  function unlock() {
    root.classList.remove('curtain-locked');
    curtain.style.visibility = 'hidden';
    curtain.style.pointerEvents = 'none';
    opened = true;
  }
  function frame() {
    ticking = false;
    displayed += (target - displayed) * 0.16;
    if (Math.abs(target - displayed) < 0.001) displayed = target;
    paint(displayed);
    if (displayed >= 1 && target === 1) { unlock(); return; }
    if (displayed !== target) schedule();
  }
  function schedule() {
    if (!ticking) { ticking = true; requestAnimationFrame(frame); }
  }
  function step(delta) {
    target = clamp(target + delta / travel());
    if (!opened) schedule();
  }
  function onWheel(e) {
    if (reduce.matches || (e.ctrlKey && e.deltaY)) return;
    if (opened && window.scrollY <= 1 && e.deltaY < 0) {
      target = 1; displayed = 1; lock();
    }
    if (!opened) {
      e.preventDefault();
      step(e.deltaMode === 1 ? e.deltaY * 16 : e.deltaMode === 2 ? e.deltaY * window.innerHeight : e.deltaY);
    }
  }
  function onTouchStart(e) { touchY = e.touches[0]?.clientY ?? null; }
  function onTouchMove(e) {
    if (touchY === null || reduce.matches) return;
    const y = e.touches[0]?.clientY;
    if (y == null) return;
    const delta = (touchY - y) * 1.4;
    touchY = y;
    if (opened && window.scrollY <= 1 && delta < 0) { target = 1; displayed = 1; lock(); }
    if (!opened) { e.preventDefault(); step(delta); }
  }
  function onKey(e) {
    if (reduce.matches) return;
    const amount = ({ ArrowDown: 100, ArrowUp: -100, PageDown: 300, PageUp: -300, ' ': e.shiftKey ? -300 : 300 })[e.key];
    if (amount === undefined) return;
    if (opened && window.scrollY <= 1 && amount < 0) { target = 1; displayed = 1; lock(); }
    if (!opened) { e.preventDefault(); step(amount); }
  }
  function onMotionChange() {
    if (reduce.matches) { target = displayed = 1; paint(1); unlock(); }
    else if (window.scrollY <= 1) { target = displayed = 0; paint(0); lock(); }
  }
  window.addEventListener('wheel', onWheel, { passive: false });
  window.addEventListener('touchstart', onTouchStart, { passive: true });
  window.addEventListener('touchmove', onTouchMove, { passive: false });
  window.addEventListener('keydown', onKey);
  reduce.addEventListener?.('change', onMotionChange);
  // Restore native navigation when following an internal section link.
  document.querySelectorAll('a[href^="#"]').forEach(a => a.addEventListener('click', () => {
    target = displayed = 1; paint(1); unlock();
  }));
  if (reduce.matches || window.scrollY > 1 || window.location.hash) {
    target = displayed = 1; paint(1); unlock();
  } else {
    paint(0); lock();
  }
})();
