// The document scroll drives the two curtain panels.
// During the first viewport of scrolling, the page stays visually in place.
(() => {
  const curtain = document.getElementById('openingCurtain');
  const site = document.getElementById('portfolioSite');
  const spacer = document.getElementById('curtainScrollSpace');
  const left = curtain.querySelector('.wing-left');
  const right = curtain.querySelector('.wing-right');
  const center = curtain.querySelector('.curtain-center');
  const bar = curtain.querySelector('.curtain-progress-bar');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let distance = 0;
  let raf = 0;

  function update() {
    raf = 0;
    if (reducedMotion.matches) {
      curtain.style.visibility = 'hidden';
      site.style.transform = '';
      spacer.style.height = '0';
      return;
    }
    const y = Math.max(0, window.scrollY);
    const progress = Math.min(y / distance, 1);
    left.style.transform = `translateX(${-103 * progress}%) rotateY(${-13 * progress}deg)`;
    right.style.transform = `translateX(${103 * progress}%) rotateY(${13 * progress}deg)`;
    center.style.opacity = String(Math.max(0, 1 - progress * 3));
    bar.style.transform = `scaleX(${progress})`;
    curtain.style.visibility = progress >= 1 ? 'hidden' : 'visible';
    site.style.transform = `translate3d(0, ${Math.min(y, distance)}px, 0)`;
  }
  function requestUpdate() { if (!raf) raf = requestAnimationFrame(update); }
  function setDistance() {
    distance = Math.max(360, Math.round(window.innerHeight * 0.94));
    spacer.style.height = `${distance}px`;
    requestUpdate();
  }
  window.addEventListener('scroll', requestUpdate, { passive: true });
  window.addEventListener('resize', setDistance, { passive: true });
  reducedMotion.addEventListener?.('change', setDistance);
  setDistance();
})();
