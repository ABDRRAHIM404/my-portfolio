# Abderrahim — portfolio

Open `index.html` in any browser. HTML, CSS, and JavaScript live in separate files.

## Change the profile photo

The hero now uses your local photo at `assets/profile.jpg`. If you want to replace it later, keep the same filename or update the `src` in `index.html`. The local placeholder is `assets/avatar-placeholder.svg`.

## Projects

Four repository links and live site links are included. The demo links are from each repository's homepage metadata; check their published status before sharing the site publicly.

## Before publishing

Replace `your-email@example.com` in `index.html` with your actual email.

## CV

Your original HTML CV is included at `assets/Abderrahim_Bounga_CV.html`; the home and contact sections link to it. The contact email comes from the CV.

## English / Français

Use the EN / FR switch in the navigation to translate the entire portfolio. Your choice is remembered locally. All translations are in `js/translations.js`; no translation service or internet connection is needed. The original CV is in French and opens separately.
