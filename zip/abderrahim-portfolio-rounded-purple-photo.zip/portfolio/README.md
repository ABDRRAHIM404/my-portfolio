# Abderrahim — portfolio

Open `index.html` in any browser. HTML, CSS, and JavaScript live in separate files.

## Change the profile photo

The hero now uses your local photo at `assets/profile.jpg`. If you want to replace it later, keep the same filename or update the `src` in `index.html`. The local placeholder is `assets/avatar-placeholder.svg`.

## Projects

Four repository links and live site links are included. The demo links are from each repository's homepage metadata; check their published status before sharing the site publicly.

## Before publishing

Replace `your-email@example.com` in `index.html` with your actual email.

## CV

Your original HTML CV is included at `assets/Abderrahim_Bounga_CV.html`; the home and contact sections link to it. The contact email comes from the CV.

## English / Français

Use the EN / FR switch in the navigation to translate the entire portfolio. Your choice is remembered locally. All translations are in `js/translations.js`; no translation service or internet connection is needed. The original CV is in French and opens separately.

## Scroll curtain introduction

Open index.html and scroll down: two dark-purple panels open to reveal the portfolio. Scroll back to the top and continue scrolling upward to close them. The reveal now animates separately from the website, preventing page jumps. The effect is written in `css/style.css` and `js/curtain.js`. Reduced-motion visitors skip the intro. GitHub and LinkedIn links are in the hero and footer.

## Animated opening
The opening monogram expands **A → Abderrahim** and **B → Bounga**, while a glowing violet line highlights the curtain seam. Scroll to expand the name and open the panels. The portfolio layout stays fixed underneath. Reduced-motion settings skip the introduction.

## Curtain timing
The curtain holds closed for the first 38% of scroll progress while the initials expand into your name. The doors then open smoothly. Adjust the `0.38` threshold in `js/curtain.js` for a shorter or longer hold.

The center seam glows continuously and fades only in the final part of the curtain opening.

## Moving light and name

The AB-to-name animation and brighter glowing seams are attached to the left and right curtain panels, so they travel outward with the panels. The centered helper text fades before the doors open. Edit CSS section `Tracking edge lights and names` to adjust glow density.


## Hero magic

This version adds floating particles, a cursor spotlight, portrait aura, animated text shine, and subtle 3D mouse parallax to the hero section while keeping the curtain intro unchanged. On mobile and reduced-motion settings, interactions are simplified automatically.


## Hero fix

This version softens the 3D parallax and repositions the portrait labels so they no longer get cut off or overlap the caption. Decorative rings remain behind the photo and are toned down on smaller screens.

## Photo polish
Rounded portrait corners and an always-visible subtle purple tint that fades on hover (touch devices keep the tint).
