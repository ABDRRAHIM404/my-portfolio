document.getElementById('year').textContent = new Date().getFullYear();
    const menuButton = document.getElementById('menuButton');
    const nav = document.getElementById('mainNav');
    menuButton.addEventListener('click', () => {const isOpen = nav.classList.toggle('open');menuButton.setAttribute('aria-expanded', String(isOpen));menuButton.setAttribute('aria-label',isOpen?'Close navigation':'Open navigation')});
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuButton.setAttribute('aria-expanded','false')}));
    if ('IntersectionObserver' in window){const observer = new IntersectionObserver((entries)=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}})},{threshold:.08});document.querySelectorAll('.reveal').forEach(el=>observer.observe(el))}else{document.querySelectorAll('.reveal').forEach(el=>el.classList.add('visible'))}
